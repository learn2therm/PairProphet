learn2therm_sample_50k.csv is a randomly generated sample dataset from the learn2therm database.

Parameters:
Selected only from protein pairs containing ogt difference >= 20 C

Total dataset size:
53302409

Total sample size:
50000 